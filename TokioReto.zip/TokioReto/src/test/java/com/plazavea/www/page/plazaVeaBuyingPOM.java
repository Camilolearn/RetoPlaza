package com.plazavea.www.page;


import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;


@DefaultUrl("https://www.plazavea.com.pe/")

public class plazaVeaBuyingPOM extends PageObject{
	// Se definen los elementos o localizadores de plazavea
	@FindBy(id="search_box")
	WebElement writing;
	
	@FindBy(css=".SuggestionItem:nth-child(2) .SuggestionItem__productName > a")
	WebElement productSelect;//producto sele
	
	@FindBy(id="ProductCard__add-to-cart")
	WebElement addCar;
	
	@FindBy(css=".cart__number")
	WebElement carList;
	
	@FindBy(css=".button")
	WebElement followCar;
	
	//Se definen los metodos a usar durante le paso a paso en la clase BuyingSteps.java
	 public void sendData() {	
		 writing.sendKeys("scooter");
	} 
	 public void selectProducts() {
		 productSelect.click();
	 }
	 public void addProduct() {
		 addCar.click();
	 }
	
	 public void car() {
			carList.click();
			followCar.click();
		}
		
}
