package com.plazavea.www.page;

import net.thucydides.core.annotations.Step;

public class BuyingSteps {
	
	plazaVeaBuyingPOM plazabuying = new plazaVeaBuyingPOM();
	//Abrir el navegador
	@Step("Open Chrome")
	public void openApplication() {
		plazabuying.open();
	}
	//Escribir sobre el buscador
	@Step("write product name")
	public void writeData(){
		plazabuying.sendData();
	}
	//Escoger producto
	@Step("select product")
	public void product() {
		plazabuying.selectProducts();
	}
	//A�adir producto
	@Step("add product")
    public void addProduct() {
		 plazabuying.addProduct();
		 plazabuying.car();
		
	 }
	
	
	

}
	
   

