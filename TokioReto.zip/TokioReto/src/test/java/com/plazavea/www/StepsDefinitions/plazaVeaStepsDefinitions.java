package com.plazavea.www.StepsDefinitions;

import com.plazavea.www.page.BuyingSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class plazaVeaStepsDefinitions {
	
	@Steps // The @Steps annotation marks a Serenity step library
	BuyingSteps buying;
	
	
	//Abre el navegador chrome. 
	@Given("^that I go to plazavea home page$")
	public void that_I_go_to_plazavea_home_page() {
		buying.openApplication();
	}

	//Escribe sobre el buscador del home page el producto
	@When("^fill the search with my favorite article$")
	public void fill_the_search_with_my_favorite_article() {
		buying.writeData();
	}
	//Selecciona el producto.
	@When("^adding the product$")
	public void adding_the_product() {
		buying.product();
	}
	//Agrega el producto al carrito
	@Then("^i Validate that it was added$")
	public void i_Validate_that_it_was_added() {
		buying.addProduct();
		System.out.println("COMPRA VALIDADA");
	}

			 
	 
}
