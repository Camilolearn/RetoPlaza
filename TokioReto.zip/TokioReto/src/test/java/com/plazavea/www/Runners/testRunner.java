package com.plazavea.www.Runners;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features="feature/BuySteps.feature",
glue="com.plazavea.www.StepsDefinitions")
public class testRunner {
	

}
